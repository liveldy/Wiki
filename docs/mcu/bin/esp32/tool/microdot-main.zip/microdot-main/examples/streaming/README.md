This directory contain examples that demonstrate how to use streaming responses.
