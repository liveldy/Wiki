The example in this directory demonstrates how to serve static files out of a
directory.
