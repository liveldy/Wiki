This directory contains a few example applications for different
configurations of Microdot, plus similar implementations for other web
frameworks.

The *run.py* script runs these applications and reports memory usage for each.
