#include "student.h"
#include <iostream>

StudentManager::StudentManager(int capacity) {
    this->capacity = capacity;
    this->students = new Student[capacity];
    this->size = 0;
}

StudentManager::~StudentManager() {
    delete[] students;
}

void StudentManager::addStudent(const std::string& name, int rollNumber, float marks) {
    if (size < capacity) {
        students[size].name = name;
        students[size].rollNumber = rollNumber;
        students[size].marks = marks;
        size++;
        std::cout << "Student added successfully." << std::endl;
    } else {
        std::cout << "Student database is full." << std::endl;
    }
}

void StudentManager::displayStudents() {
    if (size == 0) {
        std::cout << "No students to display." << std::endl;
        return;
    }

    std::cout << "List of students:" << std::endl;
    for (int i = 0; i < size; ++i) {
        std::cout << "Name: " << students[i].name << ", Roll Number: " << students[i].rollNumber << ", Marks: " << students[i].marks << std::endl;
    }
}

void StudentManager::searchStudent(int rollNumber) {
    for (int i = 0; i < size; ++i) {
        if (students[i].rollNumber == rollNumber) {
            std::cout << "Student found:" << std::endl;
            std::cout << "Name: " << students[i].name << ", Roll Number: " << students[i].rollNumber << ", Marks: " << students[i].marks << std::endl;
            return;
        }
    }
    std::cout << "Student with roll number " << rollNumber << " not found." << std::endl;
}

void StudentManager::deleteStudent(int rollNumber) {
    int index = -1;
    for (int i = 0; i < size; ++i) {
        if (students[i].rollNumber == rollNumber) {
            index = i;
            break;
        }
    }
    if (index != -1) {
        for (int i = index; i < size - 1; ++i) {
            students[i] = students[i + 1];
        }
        size--;
        std::cout << "Student deleted successfully." << std::endl;
    } else {
        std::cout << "Student with roll number " << rollNumber << " not found." << std::endl;
    }
}
