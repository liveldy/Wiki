#ifndef STUDENT_H
#define STUDENT_H

#include <string>

struct Student {
    std::string name;
    int rollNumber;
    float marks;
};

class StudentManager {
private:
    Student* students;
    int capacity;
    int size;

public:
    StudentManager(int capacity);
    ~StudentManager();

    void addStudent(const std::string& name, int rollNumber, float marks);
    void displayStudents();
    void searchStudent(int rollNumber);
    void deleteStudent(int rollNumber);
};

#endif
