#include "student.h"
#include <iostream>
#include <string>

void displayMenu() {
    std::cout << "=== Student Management System ===" << std::endl;
    std::cout << "1. Add Student" << std::endl;
    std::cout << "2. Display All Students" << std::endl;
    std::cout << "3. Search Student" << std::endl;
    std::cout << "4. Delete Student" << std::endl;
    std::cout << "5. Exit" << std::endl;
    std::cout << "=================================" << std::endl;
    std::cout << "Enter your choice: ";
}

int main() {
    StudentManager manager(10); // Create a student manager with capacity for 10 students

    int choice;
    std::string name;
    int rollNumber;
    float marks;

    do {
        displayMenu();
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter student name: ";
                std::cin >> name;
                std::cout << "Enter student roll number: ";
                std::cin >> rollNumber;
                std::cout << "Enter student marks: ";
                std::cin >> marks;
                manager.addStudent(name, rollNumber, marks);
                break;
            case 2:
                manager.displayStudents();
                break;
            case 3:
                std::cout << "Enter roll number to search: ";
                std::cin >> rollNumber;
                manager.searchStudent(rollNumber);
                break;
            case 4:
                std::cout << "Enter roll number to delete: ";
                std::cin >> rollNumber;
                manager.deleteStudent(rollNumber);
                break;
            case 5:
                std::cout << "Exiting program." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 5);

    return 0;
}
